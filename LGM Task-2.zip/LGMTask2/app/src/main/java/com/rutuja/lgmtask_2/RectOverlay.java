package com.rutuja.lgmtask_2;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class RectOverlay extends  GraphicOverlay.Graphic{
    private int reactColor = Color.GREEN;
    private float strokeWidth = 4.5f;
    private Paint reactPaint;
    private GraphicOverlay graphicOverlay;
    private Rect rect;

    public RectOverlay(GraphicOverlay overlay, Rect rect) {
        super(overlay);
        reactPaint = new Paint();
        reactPaint.setColor(reactColor);
        reactPaint.setStyle(Paint.Style.STROKE);
        reactPaint.setStrokeWidth(strokeWidth);

        this.graphicOverlay = overlay;
        this.rect = rect;

        postInvalidate();
    }

    @Override
    public void draw(Canvas canvas) {
        RectF rectF = new RectF(rect);
        rectF.left = translateX(rectF.left);
        rectF.right = translateX(rectF.right);
        rectF.top = translateX(rectF.top);
        rectF.bottom = translateX(rectF.bottom);

        canvas.drawRect(rect, reactPaint);
    }
}
